# Super Mario Game - Melhorias Implementadas

## 📋 Resumo das Evoluções

Este documento descreve todas as melhorias implementadas no jogo Super Mario conforme solicitado na atividade.

---

## 🎵 1. Sistema de Sons

### Sons Implementados:
- **Música de fundo** (`game.mp3`): Toca continuamente durante o gameplay
- **Som de pulo** (`jump.wav`): Reproduzido cada vez que o Mario pula
- **Som de morte** (`mariodie.wav`): Toca quando o Mario colide com um obstáculo
- **Som de power-up** (`powerup.wav`): Toca quando o Mario evolui de nível

### Características:
- A música de fundo inicia automaticamente no primeiro pulo (interação do usuário)
- Volume da música ajustado para 30% para não sobrepor os efeitos sonoros
- Música pausa automaticamente quando o jogo termina
- Todos os sons reiniciam do início para evitar sobreposição

---

## 🚧 2. Novos Obstáculos

### Obstáculos Adicionados:
1. **Pipe (Cano)** - Obstáculo original mantido
   - Velocidade: 2 segundos para atravessar a tela
   - Altura: 112px
   - Posição: No chão

2. **Turtle (Tartaruga)** - Novo obstáculo
   - Velocidade: 3 segundos para atravessar a tela
   - Altura: 80px de colisão
   - Posição: No chão
   - Delay: 1 segundo após início

3. **Bullet (Projétil)** - Novo obstáculo
   - Velocidade: 2.5 segundos para atravessar a tela
   - Altura: 180px (altura média do pulo)
   - Posição: No ar
   - Delay: 2 segundos após início

### Sistema de Colisão:
- Detecção precisa para cada obstáculo
- Colisão com bullet verifica se Mario está na altura do pulo (100-200px)
- Colisão com pipe e turtle verifica altura inferior a 112px e 80px respectivamente

---

## 🎮 3. Sistema de Evolução do Mario

### Níveis de Evolução:

#### 🌟 Mario Starter (0-5 pontos)
- **Sprite**: `mario-starter.gif`
- **Descrição**: Mario iniciante
- **Nível**: Básico

#### ⭐ Mario Beginner (6-10 pontos)
- **Sprite**: `mario-beginner.gif`
- **Descrição**: Mario intermediário
- **Evolução**: Toca som de power-up na primeira vez que atinge 6 pontos
- **Nível**: Intermediário

#### 🌟🌟 Mario Pro (11+ pontos)
- **Sprite**: `mario-pro.gif`
- **Descrição**: Mario profissional
- **Evolução**: Toca som de power-up na primeira vez que atinge 11 pontos
- **Animação especial**: Quando pula, aparece `mario-flying.gif` (Mario voando)
- **Nível**: Avançado

### Mecânica de Evolução:
- A pontuação aumenta a cada pulo bem-sucedido
- O sprite muda automaticamente ao atingir os marcos de pontuação
- Som de power-up toca apenas na primeira vez que cada nível é alcançado
- Mario Pro tem animação especial de voo durante o pulo

---

## 🎯 4. Melhorias na Jogabilidade

### Ajustes de Velocidade:
- **Pipe**: 2s (velocidade moderada)
- **Turtle**: 3s (velocidade mais lenta)
- **Bullet**: 2.5s (velocidade média-alta)

### Delays entre Obstáculos:
- Pipe: sem delay (inicia imediatamente)
- Turtle: 1 segundo de delay
- Bullet: 2 segundos de delay

Esses delays garantem que os obstáculos não apareçam todos ao mesmo tempo, tornando o jogo mais jogável.

---

## 💻 Como Jogar

1. Abra o arquivo `index.html` em um navegador web
2. Pressione qualquer tecla ou toque na tela para fazer o Mario pular
3. Desvie dos obstáculos (pipe, turtle e bullet)
4. Acumule pontos para evoluir o Mario
5. Tente bater seu próprio recorde!

### Controles:
- **Qualquer tecla do teclado**: Faz o Mario pular
- **Toque na tela** (mobile): Faz o Mario pular
- **Botão "Retry now"**: Reinicia o jogo após Game Over
