const mario = document.querySelector('.mario');
const pipe = document.querySelector('.pipe');
const turtle = document.querySelector('.turtle');
const bullet = document.querySelector('.bullet');
const gameOver = document.querySelector('.game-over');
const score = document.querySelector('.score');
const highScore = document.querySelector('#high-score');

// Sistema de Sons
const backgroundMusic = new Audio('./sound/game.mp3');
const jumpSound = new Audio('./sound/jump.wav');
const dieSound = new Audio('./sound/mariodie.wav');
const powerUpSound = new Audio('./sound/powerup.wav');

// Configurar música de fundo
backgroundMusic.loop = true;
backgroundMusic.volume = 0.3;

// Iniciar música de fundo quando o jogo começar
let musicStarted = false;

const startBackgroundMusic = () => {
    if (!musicStarted) {
        backgroundMusic.play().catch(e => console.log('Erro ao tocar música:', e));
        musicStarted = true;
    }
};

const setCookie = function (name, value, expirationDays) {
    const date = new Date();
    date.setTime(date.getTime() + (expirationDays * 24 * 60 * 60 * 1000));
    let expires = "expires=" + date.toUTCString();

    document.cookie = name + "=" + value + ";" + expires + ";SameSite=Lax;path=/";
};

const getCookie = function (name) {
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    name = name + "=";

    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];

        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }

        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }

    return "0";
};

var scoreValue = 0;
var highScoreValue = parseInt(getCookie('high-score')) || 0;

highScore.textContent = highScoreValue;
score.textContent = scoreValue;

// Variável para controlar o estado do Mario
var marioState = 'starter'; // starter, beginner, pro
var loop = null;

const updateMarioSprite = () => {
    let newSprite = './images/mario-starter.gif';
    
    if (scoreValue >= 11) {
        if (marioState !== 'pro') {
            marioState = 'pro';
            powerUpSound.currentTime = 0;
            powerUpSound.play().catch(e => console.log('Erro ao tocar som:', e));
        }
        newSprite = './images/mario-pro.gif';
    } else if (scoreValue >= 6) {
        if (marioState !== 'beginner') {
            marioState = 'beginner';
            powerUpSound.currentTime = 0;
            powerUpSound.play().catch(e => console.log('Erro ao tocar som:', e));
        }
        newSprite = './images/mario-beginner.gif';
    } else {
        marioState = 'starter';
        newSprite = './images/mario-starter.gif';
    }
    
    if (!mario.classList.contains('jump')) {
        mario.src = newSprite;
    }
};

const jump = () => {
    if (
        gameOver.style.display === 'block'
        || mario.classList.contains('jump')
    ) {
        return;
    }

    // Iniciar música de fundo na primeira interação
    startBackgroundMusic();

    mario.classList.add('jump');

    // Tocar som de pulo
    jumpSound.currentTime = 0;
    jumpSound.play().catch(e => console.log('Erro ao tocar som:', e));

    scoreValue += 1;
    score.textContent = scoreValue;

    if (highScoreValue < scoreValue) {
        setCookie('high-score', scoreValue, 365);
        highScoreValue = scoreValue;
        highScore.textContent = highScoreValue;
    }

    // Atualizar sprite do Mario baseado na pontuação
    updateMarioSprite();

    // Se Mario Pro, usar sprite voando durante o pulo
    if (marioState === 'pro') {
        mario.src = './images/mario-flying.gif';
    }

    setTimeout(() => {
        mario.classList.remove('jump');
        // Restaurar sprite correto após o pulo
        updateMarioSprite();
    }, 500);
}

const checkCollision = (obstaclePosition, obstacleWidth, marioPosition, minHeight) => {
    return (
        obstaclePosition <= 120
        && obstaclePosition > 0
        && marioPosition < minHeight
    );
};

const waitingFailure = () => {
    const pipePosition = pipe.offsetLeft;
    const turtlePosition = turtle.offsetLeft;
    const bulletPosition = bullet.offsetLeft;
    const marioPosition = +window.getComputedStyle(mario).bottom.replace('px', '');

    // Verificar colisão com pipe
    const hitPipe = checkCollision(pipePosition, 80, marioPosition, 112);
    
    // Verificar colisão com tartaruga
    const hitTurtle = checkCollision(turtlePosition, 100, marioPosition, 80);
    
    // Verificar colisão com bullet (está mais alto)
    const hitBullet = (
        bulletPosition <= 120
        && bulletPosition > 0
        && marioPosition >= 100
        && marioPosition <= 200
    );

    if (hitPipe || hitTurtle || hitBullet) {
        mario.style.animationPlayState = 'paused';
        mario.style.bottom = `${marioPosition}px`;

        pipe.style.animation = 'none';
        pipe.style.left = `${pipePosition}px`;
        
        turtle.style.animation = 'none';
        turtle.style.left = `${turtlePosition}px`;
        
        bullet.style.animation = 'none';
        bullet.style.left = `${bulletPosition}px`;

        mario.src = './images/game-over.png';
        mario.style.width = '75px';
        mario.style.marginLeft = '50px';

        gameOver.style.display = 'block';

        // Tocar som de morte e pausar música de fundo
        dieSound.currentTime = 0;
        dieSound.play().catch(e => console.log('Erro ao tocar som:', e));
        backgroundMusic.pause();

        if (loop) {
            clearInterval(loop);
        }

        document.removeEventListener('keydown', jump);
        document.removeEventListener('touchstart', jump);
    }
};

const restartGame = function () {
    console.log('Reiniciando jogo...');
    
    gameOver.style.display = 'none';

    mario.classList.remove('jump');
    mario.style.animationPlayState = 'running';
    mario.src = './images/mario-starter.gif';
    mario.style.width = '150px';
    mario.style.marginLeft = '0';
    mario.style.bottom = '0';

    pipe.style.left = '';
    pipe.style.animation = 'pipe-animation 1.5s infinite linear';
    
    turtle.style.left = '';
    turtle.style.animation = 'turtle-animation 2s infinite linear';
    
    bullet.style.left = '';
    bullet.style.animation = 'bullet-animation 1.2s infinite linear';

    scoreValue = 0;
    score.textContent = scoreValue;
    marioState = 'starter';

    // Reiniciar música de fundo
    backgroundMusic.currentTime = 0;
    backgroundMusic.play().catch(e => console.log('Erro ao tocar música:', e));

    document.addEventListener('keydown', jump);
    document.addEventListener('touchstart', jump);

    if (loop) {
        clearInterval(loop);
    }
    loop = setInterval(waitingFailure, 10);
};

// Iniciar o loop de verificação de colisão
loop = setInterval(waitingFailure, 10);

// Event listeners
document.querySelector('.retry').addEventListener('click', restartGame);
document.addEventListener('keydown', jump);
document.addEventListener('touchstart', jump);
